package ejercicioCasa;

public enum TipoHabitacion {
	
	BA�O,SALON,DORMITORIO,COCINA,TERRAZA
	
}
