package guerreros;

public class Hechizo extends Arma{

	public void usar() {
		
		System.out.println("El personaje lanza un MAL�FICO HECHIZO!");
		
	}
	
}
