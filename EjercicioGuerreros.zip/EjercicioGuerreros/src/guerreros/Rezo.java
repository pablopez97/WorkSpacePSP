package guerreros;

public class Rezo extends Arma{

	public void usar() {
		
		System.out.println("El personaje REZA... en serio? reza?... menudo ataque...");
		
	}
	
}
