package guerreros;

public class Espada extends Arma{
	
	public void usar() {
		
		System.out.println("El personaje blande su flamanete espada y ATACA!");
		
	}
	
}
