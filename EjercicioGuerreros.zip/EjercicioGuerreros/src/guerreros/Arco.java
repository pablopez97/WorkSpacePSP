package guerreros;

public class Arco extends Arma{

	public void usar() {
		
		System.out.println("El personaje apunta con su arco y DISPARA!");
		
	}
	
}
